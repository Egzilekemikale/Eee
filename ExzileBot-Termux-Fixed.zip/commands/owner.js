
exports.run = async (client, msg, args) => {
    msg.reply("👑 *Owner: Exzile Admin*\nContact: wa.me/1234567890");
};
